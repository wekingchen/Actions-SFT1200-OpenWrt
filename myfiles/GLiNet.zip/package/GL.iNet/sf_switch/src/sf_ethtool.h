#ifndef _SF_ETHTOOL_H_
#define _SF_ETHTOOL_H_

extern struct ethtool_ops sf_ethtool_ops;

#endif /* ifndef _SF_ETHTOOL_H_ */
