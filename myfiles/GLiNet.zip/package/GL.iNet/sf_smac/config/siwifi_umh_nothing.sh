#!/bin/sh
#siwifi_umh.sh is for debugging when an assert occurred
#But now it do nothing,just to reduce log such as "Failed to call /bin/siwifi_umh.sh (/bin/siwifi_umh.sh returned -2)"
#The siwifi_umh.sh with actual content is added by siwifitools
