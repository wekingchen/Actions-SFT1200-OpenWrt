#!/bin/sh
sfwifi reset&
